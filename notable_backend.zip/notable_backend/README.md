# notable_backend

Problem​: We need a way to automatically integrate doctor’s calendars from their existing systems of records with the Notable platform. The task is to build a web back-end that supports the following functionality via HTTP requests:

● Get a list of all doctors
● Get a list of all appointments for a particular doctor and particular day
● Delete an existing appointment from a doctor's calendar
● Add a new appointment to a doctor's calendar
○ New appointments can only start at 15 minute intervals (ie, 8:15AM is a valid time but 8:20AM is not)


○ A doctor can have multiple appointments with the same time, but no more than 3 appointments can be added with the same time for a given doctor
An example web UI that would be built on top of this backend is shown below. Doctors should have a unique ID, a first name, and a last name. Appointments should have a unique ID, patient first name, patient last name, date & time, and kind (New Patient or Follow-up). The backend must respond to HTTP requests (ie GET, POST, DELETE).
For this exercise, the data can just be kept in memory (such that any changes will be reset on server restarts), though you’re welcome to use a database if you prefer. You are free to use any languages, frameworks, libraries, scaffolding, starter packs, etc that you’d like. With your response, please include a zip file with your source code (preferably in a git repository), and instructions for how to run the application locally.

Doctors
-ID(primary)
-firstName
-lastName

Appointments
-ID(primary)
-patientFirstName
-patientLastName
-date(ca only start in 15 minute intervals)
-kind(new patient or Follow-up)
-Doctor(foreign key)

GET
POST
DELETE